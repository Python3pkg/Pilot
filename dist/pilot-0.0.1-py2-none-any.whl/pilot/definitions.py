class RelationshipType:
    child = 1
    parent = 2
    neighbor = 3

class ContainerType:
    value = 1
    list = 2
    dict = 3