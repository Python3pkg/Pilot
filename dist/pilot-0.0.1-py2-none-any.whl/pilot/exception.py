class InvalidConfiguration(Exception):
    pass

class InvalidClassConversion(Exception):
    pass
