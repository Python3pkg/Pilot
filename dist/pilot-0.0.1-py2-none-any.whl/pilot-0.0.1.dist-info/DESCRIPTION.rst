Pilot is a python library that allows for injecting callback hooks into tree/graph traversal, as well as for providing metadata about traversed nodes and their relationships.


